import datetime
import json
import random
import os

_DOWNLOAD_PATH = "Download/" 
_N = 0

class Article:

    def __init__(self, name):
        self.name = name
        self.likes = random.randint(0, 100)
        

def json_dump_article(art: Article):
    global _N
    _N += 1
    dt = datetime.datetime.now()
    dt_str = dt.strftime('%Y-%m-%d_%H-%M-%S') 
    path = f'{_DOWNLOAD_PATH}{_N}_{dt_str}.json'
    os.makedirs(_DOWNLOAD_PATH, exist_ok=True)  # Создаёт папку, если её нет
    with open(path, 'w') as f:  # Используем режим 'w' для перезаписи
        json.dump(art.__dict__, f)
    print(f"Article saved to {path}")
        

def get_article():
    art = Article(f"Article {random.randint(1000, 9999)}")
    return art

def do_work():
    art = get_article()
    json_dump_article(art)

def list_files():
    """Выводит список файлов в папке Download."""
    if not os.path.exists(_DOWNLOAD_PATH):
        print("No files found.")
        return []

    files = os.listdir(_DOWNLOAD_PATH)
    for idx, file in enumerate(files):
        print(f"{idx + 1}. {file}")
    return files

def delete_file():
    """Удаляет файл по выбору пользователя."""
    files = list_files()
    if not files:
        return

    try:
        choice = int(input("Enter the number of the file to delete (or 0 to cancel): "))
        if choice == 0:
            print("Deletion cancelled.")
            return

        file_to_delete = files[choice - 1]
        os.remove(os.path.join(_DOWNLOAD_PATH, file_to_delete))
        print(f"File {file_to_delete} deleted.")
    except (ValueError, IndexError):
        print("Invalid choice. No files were deleted.")

def add_new_articles():
    """Добавляет новые статьи по запросу пользователя."""
    try:
        count = int(input("How many new articles do you want to add? "))
        for _ in range(count):
            do_work()
    except ValueError:
        print("Invalid input. No articles were added.")

# Основная часть программы
for i in range(10):
    do_work()

while True:
    print("\nOptions:")
    print("1. List files")
    print("2. Delete a file")
    print("3. Add new articles")
    print("4. Exit")

    choice = input("Choose an option: ")

    if choice == '1':
        list_files()
    elif choice == '2':
        delete_file()
    elif choice == '3':
        add_new_articles()
    elif choice == '4':
        print("Exiting program.")
        break
    else:
        print("Invalid choice. Please try again.")

